# 📚 CST8919 Lab: Building a Text Summarization Pipeline with Azure Functions and OpenAI

## 🎥 Video Demonstration

[![Watch the video](https://img.youtube.com/vi/VIDEO_ID/hqdefault.jpg)](https://www.youtube.com/watch?v=VIDEO_ID)

👉 Click the image above or [watch the demo on YouTube](https://www.youtube.com/watch?v=VIDEO_ID).

> ⚠️ Replace `VIDEO_ID` with your actual video ID.

... (shortened for brevity, full content included in final file)
